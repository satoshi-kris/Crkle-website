// CRKLE Background Service Worker
// Handles API communication, analytics, and extension lifecycle

class CRKLEBackground {
  constructor() {
    this.apiEndpoint = 'https://api.crkle.com';
    this.supportedPlatforms = [
      'bolt.new',
      'lovable.dev', 
      'cursor.sh',
      'replit.com'
    ];
    
    this.setupEventListeners();
    this.initializeExtension();
  }

  setupEventListeners() {
    // Extension lifecycle events
    chrome.runtime.onInstalled.addListener(this.handleInstall.bind(this));
    chrome.runtime.onStartup.addListener(this.handleStartup.bind(this));
    
    // Message handling
    chrome.runtime.onMessage.addListener(this.handleMessage.bind(this));
    
    // Tab change events
    chrome.tabs.onUpdated.addListener(this.handleTabUpdate.bind(this));
    chrome.tabs.onActivated.addListener(this.handleTabActivated.bind(this));
  }

  async initializeExtension() {
    // Set default settings if not already set
    const settings = await chrome.storage.sync.get([
      'realtime', 'autoenhance', 'scores', 'notifications'
    ]);
    
    const defaults = {
      realtime: true,
      autoenhance: false,
      scores: true,
      notifications: true
    };
    
    const toSet = {};
    for (const [key, defaultValue] of Object.entries(defaults)) {
      if (settings[key] === undefined) {
        toSet[key] = defaultValue;
      }
    }
    
    if (Object.keys(toSet).length > 0) {
      await chrome.storage.sync.set(toSet);
    }
    
    // Initialize user stats if not set
    const stats = await chrome.storage.local.get(['promptsEnhanced', 'timesSaved', 'firstInstall']);
    if (stats.firstInstall === undefined) {
      await chrome.storage.local.set({
        promptsEnhanced: 0,
        timesSaved: 0,
        firstInstall: Date.now(),
        lastActive: Date.now()
      });
    }
  }

  async handleInstall(details) {
    console.log('🧠 CRKLE installed!', details);
    
    if (details.reason === 'install') {
      // First time installation
      await this.trackEvent('extension_installed', {
        version: chrome.runtime.getManifest().version
      });
      
      // Open welcome page
      await chrome.tabs.create({
        url: 'https://crkle.com/welcome?source=extension'
      });
      
      // Set installation timestamp
      await chrome.storage.local.set({
        installDate: Date.now(),
        installReason: 'fresh_install'
      });
      
    } else if (details.reason === 'update') {
      // Extension updated
      await this.trackEvent('extension_updated', {
        from: details.previousVersion,
        to: chrome.runtime.getManifest().version
      });
      
      // Check if we should show what's new
      const shouldShowWhatsNew = await this.shouldShowWhatsNew(details.previousVersion);
      if (shouldShowWhatsNew) {
        await chrome.tabs.create({
          url: 'https://crkle.com/whats-new?source=update'
        });
      }
    }
  }

  async handleStartup() {
    // Extension started (browser opened)
    await this.trackEvent('extension_started');
    await chrome.storage.local.set({ lastActive: Date.now() });
  }

  async handleMessage(request, sender, sendResponse) {
    try {
      switch (request.action) {
        case 'analyzePrompt':
          const analysis = await this.analyzePrompt(request.data);
          sendResponse({ success: true, data: analysis });
          break;
          
        case 'trackEvent':
          await this.trackEvent(request.event, request.data);
          sendResponse({ success: true });
          break;
          
        case 'updateStats':
          await this.updateUserStats(request.data);
          sendResponse({ success: true });
          break;
          
        case 'getSettings':
          const settings = await chrome.storage.sync.get([
            'realtime', 'autoenhance', 'scores', 'notifications'
          ]);
          sendResponse({ success: true, data: settings });
          break;
          
        default:
          sendResponse({ success: false, error: 'Unknown action' });
      }
    } catch (error) {
      console.error('Background message error:', error);
      sendResponse({ success: false, error: error.message });
    }
    
    return true; // Keep message channel open for async response
  }

  async handleTabUpdate(tabId, changeInfo, tab) {
    if (changeInfo.status === 'complete' && tab.url) {
      const isSupported = this.supportedPlatforms.some(platform => 
        tab.url.includes(platform.split('.')[0])
      );
      
      if (isSupported) {
        // Update badge to show CRKLE is active
        await chrome.action.setBadgeText({
          tabId: tabId,
          text: '●'
        });
        
        await chrome.action.setBadgeBackgroundColor({
          tabId: tabId,
          color: '#FF6B35'
        });
        
        // Track platform visit
        const platform = this.supportedPlatforms.find(p => 
          tab.url.includes(p.split('.')[0])
        );
        
        await this.trackEvent('platform_visited', { platform });
        
      } else {
        // Clear badge on unsupported sites
        await chrome.action.setBadgeText({
          tabId: tabId,
          text: ''
        });
      }
    }
  }

  async handleTabActivated(activeInfo) {
    // Update last active timestamp
    await chrome.storage.local.set({ lastActive: Date.now() });
  }

  async analyzePrompt(data) {
    const { prompt, platform, context } = data;
    
    try {
      // First try our API
      const response = await fetch(`${this.apiEndpoint}/analyze`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CRKLE-Version': chrome.runtime.getManifest().version,
          'X-CRKLE-Platform': platform
        },
        body: JSON.stringify({
          prompt,
          platform,
          context,
          user_id: await this.getUserId()
        }),
        signal: AbortSignal.timeout(10000) // 10 second timeout
      });
      
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }
      
      const analysis = await response.json();
      
      // Track successful API analysis
      await this.trackEvent('prompt_analyzed_api', {
        platform,
        quality_score: analysis.quality_score,
        suggestions_count: analysis.suggestions?.length || 0
      });
      
      return analysis;
      
    } catch (error) {
      console.warn('API analysis failed, using fallback:', error);
      
      // Fallback to local analysis
      const fallbackAnalysis = this.generateFallbackAnalysis(prompt, platform);
      
      await this.trackEvent('prompt_analyzed_fallback', {
        platform,
        error: error.message
      });
      
      return fallbackAnalysis;
    }
  }

  generateFallbackAnalysis(prompt, platform) {
    let score = 5;
    const suggestions = [];
    
    // Basic analysis
    if (prompt.length > 50) score += 1;
    if (prompt.length > 150) score += 1;
    
    // Check for common missing elements
    const hasUI = /\b(ui|interface|design|layout)\b/i.test(prompt);
    const hasTech = /\b(react|vue|javascript|typescript)\b/i.test(prompt);
    const hasFeatures = /\b(auth|login|database|api)\b/i.test(prompt);
    
    if (!hasUI) {
      suggestions.push({
        type: 'ui',
        title: '🎨 Add UI specifics',
        description: 'Describe the visual design and user interface',
        enhancement: 'with a clean, modern interface and responsive design'
      });
    }
    
    if (!hasTech) {
      suggestions.push({
        type: 'tech',
        title: '⚙️ Specify tech stack',
        description: 'Mention your preferred technologies',
        enhancement: 'using React, TypeScript, and Tailwind CSS'
      });
    }
    
    if (!hasFeatures) {
      suggestions.push({
        type: 'features',
        title: '✨ Define key features',
        description: 'List the main functionality needed',
        enhancement: 'with user authentication, data persistence, and mobile optimization'
      });
    }
    
    // Platform-specific suggestions
    const platformSuggestions = {
      'bolt.new': 'with full-stack backend integration and database setup',
      'lovable.dev': 'with beautiful animations and component design',
      'cursor.sh': 'with clean code structure and proper documentation',
      'replit.com': 'with educational comments and step-by-step implementation'
    };
    
    if (platformSuggestions[platform]) {
      suggestions.push({
        type: 'platform',
        title: `🚀 ${platform} optimization`,
        description: `Optimize for ${platform} specifically`,
        enhancement: platformSuggestions[platform]
      });
    }
    
    // Generate enhanced prompt
    let enhanced = prompt;
    suggestions.slice(0, 3).forEach(s => enhanced += ` ${s.enhancement}`);
    
    return {
      quality_score: Math.min(score, 10),
      suggestions: suggestions.slice(0, 4),
      enhanced_prompt: enhanced,
      confidence: 0.7,
      is_fallback: true,
      analysis_time: Date.now()
    };
  }

  async updateUserStats(data) {
    const { action, platform, timeSaved = 0 } = data;
    
    const currentStats = await chrome.storage.local.get([
      'promptsEnhanced', 'timesSaved', 'platformUsage'
    ]);
    
    const newStats = {
      promptsEnhanced: (currentStats.promptsEnhanced || 0) + 1,
      timesSaved: (currentStats.timesSaved || 0) + timeSaved,
      platformUsage: {
        ...currentStats.platformUsage,
        [platform]: (currentStats.platformUsage?.[platform] || 0) + 1
      },
      lastEnhancement: Date.now()
    };
    
    await chrome.storage.local.set(newStats);
    
    // Notify popup if it's open
    try {
      await chrome.runtime.sendMessage({
        action: 'statsUpdated',
        stats: newStats
      });
    } catch (error) {
      // Popup might not be open, that's okay
    }
    
    // Track milestone achievements
    await this.checkMilestones(newStats);
  }

  async checkMilestones(stats) {
    const milestones = [1, 5, 10, 25, 50, 100, 250, 500];
    const { promptsEnhanced } = stats;
    
    if (milestones.includes(promptsEnhanced)) {
      await this.trackEvent('milestone_reached', {
        milestone: promptsEnhanced,
        timesSaved: stats.timesSaved
      });
      
      // Could show achievement notification here
      this.showAchievementNotification(promptsEnhanced);
    }
  }

  async showAchievementNotification(count) {
    const messages = {
      1: "🎉 First prompt enhanced! Welcome to CRKLE!",
      5: "🔥 5 prompts enhanced! You're getting the hang of it!",
      10: "⭐ 10 prompts enhanced! CRKLE power user!",
      25: "🚀 25 prompts enhanced! You're on fire!",
      50: "💎 50 prompts enhanced! CRKLE master!",
      100: "👑 100 prompts enhanced! Legendary status!"
    };
    
    const message = messages[count];
    if (message) {
      await chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon48.png',
        title: 'CRKLE Achievement!',
        message: message
      });
    }
  }

  async trackEvent(eventName, data = {}) {
    try {
      const eventData = {
        event: eventName,
        timestamp: Date.now(),
        user_id: await this.getUserId(),
        version: chrome.runtime.getManifest().version,
        ...data
      };
      
      // Store locally for batch sending
      const events = await chrome.storage.local.get(['pendingEvents']);
      const pendingEvents = events.pendingEvents || [];
      pendingEvents.push(eventData);
      
      await chrome.storage.local.set({ pendingEvents });
      
      // Send events if we have enough queued
      if (pendingEvents.length >= 5) {
        await this.sendEventBatch(pendingEvents);
      }
      
    } catch (error) {
      console.error('Event tracking error:', error);
    }
  }

  async sendEventBatch(events) {
    try {
      await fetch(`${this.apiEndpoint}/analytics`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CRKLE-Version': chrome.runtime.getManifest().version
        },
        body: JSON.stringify({ events }),
        signal: AbortSignal.timeout(5000)
      });
      
      // Clear sent events
      await chrome.storage.local.set({ pendingEvents: [] });
      
    } catch (error) {
      console.warn('Analytics batch send failed:', error);
      // Events will be retried later
    }
  }

  async getUserId() {
    let userId = await chrome.storage.local.get(['userId']);
    
    if (!userId.userId) {
      userId.userId = 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
      await chrome.storage.local.set({ userId: userId.userId });
    }
    
    return userId.userId;
  }

  async shouldShowWhatsNew(previousVersion) {
    // Simple version comparison - show what's new for major/minor updates
    const current = chrome.runtime.getManifest().version.split('.');
    const previous = previousVersion.split('.');
    
    // Show if major or minor version changed
    return current[0] !== previous[0] || current[1] !== previous[1];
  }
}

// Initialize the background service
new CRKLEBackground();

// Periodic cleanup and maintenance
setInterval(async () => {
  try {
    // Send pending analytics events
    const events = await chrome.storage.local.get(['pendingEvents']);
    if (events.pendingEvents && events.pendingEvents.length > 0) {
      const background = new CRKLEBackground();
      await background.sendEventBatch(events.pendingEvents);
    }
    
    // Clean up old data (keep last 30 days)
    const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
    const data = await chrome.storage.local.get();
    
    // Clean up any timestamped data older than 30 days
    const toRemove = [];
    for (const [key, value] of Object.entries(data)) {
      if (typeof value === 'object' && value.timestamp && value.timestamp < thirtyDaysAgo) {
        toRemove.push(key);
      }
    }
    
    if (toRemove.length > 0) {
      await chrome.storage.local.remove(toRemove);
    }
    
  } catch (error) {
    console.error('Maintenance error:', error);
  }
}, 5 * 60 * 1000); // Every 5 minutes