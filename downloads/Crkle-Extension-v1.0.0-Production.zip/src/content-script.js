// CRKLE Content Script - The Heart of AI Prompt Enhancement
// Only activates on vibe coding platforms: Bolt.new, Lovable, Cursor, Replit

class CRKLEAgent {
  constructor() {
    this.platforms = {
      'bolt.new': {
        selectors: [
          'textarea[placeholder*="describe"]',
          'textarea[placeholder*="Tell me what to build"]',
          '.chat-input textarea',
          '[data-testid="chat-input"]',
          '.composer textarea',
          'textarea[placeholder*="What would you like to build"]'
        ],
        name: 'Bolt.new',
        color: '#FF6B35',
        icon: '⚡'
      },
      'lovable.dev': {
        selectors: [
          'textarea[placeholder*="tell me what to build"]',
          '.prompt-box textarea',
          '.chat-interface textarea',
          '[placeholder*="Describe your app"]',
          'textarea[placeholder*="What do you want to create"]'
        ],
        name: 'Lovable',
        color: '#FF6B35', 
        icon: '💜'
      },
      'cursor.sh': {
        selectors: [
          '.ai-chat textarea',
          '.composer-input textarea',
          '[data-testid="composer-input"]',
          'textarea[placeholder*="Ask Cursor"]',
          '.chat-input textarea'
        ],
        name: 'Cursor',
        color: '#FF6B35',
        icon: '⚡'
      },
      'replit.com': {
        selectors: [
          'textarea[placeholder*="Ask Replit AI"]',
          '.repl-chat textarea',
          '.ai-input textarea',
          '[placeholder*="What would you like to build"]',
          '.chat-composer textarea'
        ],
        name: 'Replit',
        color: '#FF6B35',
        icon: '🔥'
      }
    };
    
    this.currentPlatform = null;
    this.activeInput = null;
    this.enhancementOverlay = null;
    this.isAnalyzing = false;
    this.debounceTimer = null;
    
    this.init();
  }
  
  init() {
    // Only initialize on supported platforms
    if (this.detectPlatform()) {
      console.log(`🧠 CRKLE activated on ${this.currentPlatform.name}`);
      this.setupInputMonitoring();
      this.showWelcomeNotification();
    }
  }
  
  detectPlatform() {
    const hostname = window.location.hostname;
    
    for (const [domain, config] of Object.entries(this.platforms)) {
      if (hostname.includes(domain.split('.')[0])) {
        this.currentPlatform = config;
        return true;
      }
    }
    return false;
  }
  
  setupInputMonitoring() {
    // Wait for page to load completely
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => this.startMonitoring());
    } else {
      this.startMonitoring();
    }
    
    // Monitor for dynamic content changes
    const observer = new MutationObserver(() => this.findAndAttachInputs());
    observer.observe(document.body, { 
      childList: true, 
      subtree: true,
      attributes: true,
      attributeFilter: ['class', 'id']
    });
  }
  
  startMonitoring() {
    // Initial scan for inputs
    this.findAndAttachInputs();
    
    // Periodic re-scan for dynamically added inputs
    setInterval(() => this.findAndAttachInputs(), 2000);
  }
  
  findAndAttachInputs() {
    this.currentPlatform.selectors.forEach(selector => {
      try {
        const inputs = document.querySelectorAll(selector);
        inputs.forEach(input => {
          if (!input.dataset.crkleAttached) {
            this.attachToInput(input);
            input.dataset.crkleAttached = 'true';
          }
        });
      } catch (error) {
        // Ignore selector errors
      }
    });
  }
  
  attachToInput(input) {
    console.log(`📝 CRKLE monitoring input:`, input);
    
    // Monitor typing with intelligent debouncing
    input.addEventListener('input', (e) => {
      clearTimeout(this.debounceTimer);
      this.activeInput = input;
      
      const text = e.target.value.trim();
      
      if (text.length < 10) {
        this.hideEnhancementOverlay();
        return;
      }
      
      // Smart debouncing - faster for short text, slower for long
      const debounceTime = text.length > 100 ? 1500 : 1000;
      
      this.debounceTimer = setTimeout(() => {
        this.analyzePrompt(text, input);
      }, debounceTime);
    });
    
    // Show enhancement overlay on focus
    input.addEventListener('focus', (e) => {
      this.activeInput = input;
      const text = e.target.value.trim();
      
      if (text.length >= 10) {
        this.analyzePrompt(text, input);
      } else {
        this.showQuickTips(input);
      }
    });
    
    // Hide overlay when clicking outside
    document.addEventListener('click', (e) => {
      if (!this.enhancementOverlay?.contains(e.target) && 
          e.target !== input && 
          !e.target.closest('.crkle-overlay')) {
        this.hideEnhancementOverlay();
      }
    });
    
    // Add CRKLE indicator
    this.addInputIndicator(input);
  }
  
  addInputIndicator(input) {
    // Add a subtle CRKLE indicator near the input
    const indicator = document.createElement('div');
    indicator.className = 'crkle-input-indicator';
    indicator.innerHTML = `
      <div class="crkle-indicator-content">
        <span class="crkle-icon">🧠</span>
        <span class="crkle-text">CRKLE Ready</span>
      </div>
    `;
    
    // Position it appropriately
    input.parentNode.style.position = 'relative';
    input.parentNode.appendChild(indicator);
    
    // Show on hover
    input.addEventListener('mouseenter', () => {
      indicator.style.opacity = '1';
    });
    
    input.addEventListener('mouseleave', () => {
      if (input !== this.activeInput) {
        indicator.style.opacity = '0.3';
      }
    });
  }
  
  async analyzePrompt(text, input) {
    if (this.isAnalyzing) return;
    
    this.isAnalyzing = true;
    this.showAnalyzingState(input);
    
    try {
      // Call CRKLE API for prompt analysis
      const analysis = await this.callCRKLEAPI(text);
      this.showEnhancementSuggestions(analysis, input);
    } catch (error) {
      console.error('CRKLE analysis error:', error);
      // Fallback to local analysis
      const fallbackAnalysis = this.localAnalysis(text);
      this.showEnhancementSuggestions(fallbackAnalysis, input);
    }
    
    this.isAnalyzing = false;
  }
  
  async callCRKLEAPI(prompt) {
    const platform = this.currentPlatform.name.toLowerCase();
    
    const response = await fetch('https://api.crkle.com/analyze', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CRKLE-Platform': platform
      },
      body: JSON.stringify({
        prompt: prompt,
        platform: platform,
        context: {
          url: window.location.href,
          timestamp: Date.now()
        }
      })
    });
    
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    
    return await response.json();
  }
  
  localAnalysis(prompt) {
    // Fallback analysis when API is unavailable
    let score = 5;
    const suggestions = [];
    
    // Basic analysis logic
    if (prompt.length > 50) score += 1;
    if (prompt.length > 150) score += 1;
    
    // Check for specificity
    const hasUI = /\b(ui|interface|design|layout|responsive)\b/i.test(prompt);
    const hasTech = /\b(react|vue|javascript|typescript|css|html)\b/i.test(prompt);
    const hasFeatures = /\b(auth|login|database|api|users)\b/i.test(prompt);
    
    if (!hasUI) {
      suggestions.push({
        type: 'ui',
        title: '🎨 Add UI specifics',
        description: 'Describe the visual design and user interface',
        enhancement: 'with a clean, modern interface and responsive design'
      });
    }
    
    if (!hasTech) {
      suggestions.push({
        type: 'tech',
        title: '⚙️ Specify tech stack',
        description: 'Mention your preferred technologies',
        enhancement: 'using React, TypeScript, and Tailwind CSS'
      });
      score += 1;
    }
    
    if (!hasFeatures) {
      suggestions.push({
        type: 'features',
        title: '✨ Define key features',
        description: 'List the main functionality needed',
        enhancement: 'with user authentication, data persistence, and mobile optimization'
      });
    }
    
    // Platform-specific suggestions
    if (this.currentPlatform.name === 'Bolt.new') {
      suggestions.push({
        type: 'platform',
        title: '🚀 Bolt.new optimization',
        description: 'Add full-stack specific details',
        enhancement: 'with a complete backend API and database integration'
      });
    }
    
    const enhanced = this.generateEnhancedPrompt(prompt, suggestions);
    
    return {
      quality_score: Math.min(score, 10),
      suggestions: suggestions.slice(0, 4), // Max 4 suggestions
      enhanced_prompt: enhanced,
      confidence: 0.8,
      is_fallback: true
    };
  }
  
  generateEnhancedPrompt(original, suggestions) {
    let enhanced = original;
    suggestions.forEach(suggestion => {
      enhanced += ` ${suggestion.enhancement}`;
    });
    return enhanced;
  }
  
  showAnalyzingState(input) {
    this.createOverlay(input);
    this.enhancementOverlay.innerHTML = `
      <div class="crkle-analyzing">
        <div class="crkle-spinner"></div>
        <span>🧠 CRKLE is analyzing your prompt...</span>
      </div>
    `;
  }
  
  showEnhancementSuggestions(analysis, input) {
    this.createOverlay(input);
    
    const scoreClass = this.getScoreClass(analysis.quality_score);
    const scoreColor = this.getScoreColor(analysis.quality_score);
    
    this.enhancementOverlay.innerHTML = `
      <div class="crkle-header">
        <div class="crkle-branding">
          <span class="crkle-logo">🧠 CRKLE</span>
          <div class="crkle-score ${scoreClass}" style="background: ${scoreColor}">
            ${analysis.quality_score}/10
          </div>
        </div>
        <button class="crkle-close" onclick="window.crkleAgent.hideEnhancementOverlay()">×</button>
      </div>
      
      <div class="crkle-content">
        ${analysis.suggestions.length > 0 ? `
          <div class="crkle-suggestions">
            ${analysis.suggestions.map(suggestion => `
              <div class="suggestion-card" onclick="window.crkleAgent.applySuggestion('${suggestion.enhancement.replace(/'/g, "\\'")}')">
                <div class="suggestion-header">
                  <span class="suggestion-title">${suggestion.title}</span>
                </div>
                <div class="suggestion-description">${suggestion.description}</div>
                <div class="suggestion-action">+ Add This</div>
              </div>
            `).join('')}
          </div>
          
          <div class="crkle-actions">
            <button class="btn-primary" onclick="window.crkleAgent.useEnhancedPrompt('${analysis.enhanced_prompt.replace(/'/g, "\\'")}')">
              ✨ Use Enhanced Prompt
            </button>
            <button class="btn-secondary" onclick="window.crkleAgent.copyEnhancedPrompt('${analysis.enhanced_prompt.replace(/'/g, "\\'")}')">
              📋 Copy Enhanced
            </button>
          </div>
        ` : `
          <div class="crkle-perfect">
            <div class="perfect-icon">🎉</div>
            <h3>Your prompt looks great!</h3>
            <p>CRKLE thinks your prompt is well-structured and specific.</p>
          </div>
        `}
        
        ${analysis.is_fallback ? `
          <div class="crkle-fallback-notice">
            💡 Enhanced locally - connect to internet for advanced suggestions
          </div>
        ` : ''}
      </div>
    `;
  }
  
  showQuickTips(input) {
    this.createOverlay(input);
    this.enhancementOverlay.innerHTML = `
      <div class="crkle-header">
        <div class="crkle-branding">
          <span class="crkle-logo">🧠 CRKLE</span>
        </div>
        <button class="crkle-close" onclick="window.crkleAgent.hideEnhancementOverlay()">×</button>
      </div>
      
      <div class="crkle-content">
        <div class="crkle-tips">
          <h3>💡 Quick Tips for ${this.currentPlatform.name}</h3>
          <div class="tip-list">
            <div class="tip">🎯 Be specific about what you want to build</div>
            <div class="tip">🎨 Describe the UI and design style</div>
            <div class="tip">⚙️ Mention your preferred tech stack</div>
            <div class="tip">✨ List key features and functionality</div>
          </div>
          <p>Start typing and CRKLE will help enhance your prompt!</p>
        </div>
      </div>
    `;
  }
  
  createOverlay(input) {
    if (this.enhancementOverlay) {
      this.hideEnhancementOverlay();
    }
    
    this.enhancementOverlay = document.createElement('div');
    this.enhancementOverlay.className = 'crkle-overlay';
    
    this.positionOverlay(input);
    document.body.appendChild(this.enhancementOverlay);
    
    // Animate in
    setTimeout(() => {
      this.enhancementOverlay.classList.add('crkle-visible');
    }, 10);
  }
  
  positionOverlay(input) {
    const rect = input.getBoundingClientRect();
    const scrollTop = window.pageYOffset;
    const scrollLeft = window.pageXOffset;
    
    let top = rect.bottom + scrollTop + 12;
    let left = rect.left + scrollLeft;
    
    // Adjust if overlay would go off-screen
    const overlayWidth = 420;
    const overlayHeight = 300;
    
    if (left + overlayWidth > window.innerWidth) {
      left = window.innerWidth - overlayWidth - 20;
    }
    
    if (top + overlayHeight > window.innerHeight + scrollTop) {
      top = rect.top + scrollTop - overlayHeight - 12;
    }
    
    this.enhancementOverlay.style.position = 'absolute';
    this.enhancementOverlay.style.left = `${Math.max(10, left)}px`;
    this.enhancementOverlay.style.top = `${Math.max(10, top)}px`;
    this.enhancementOverlay.style.zIndex = '999999';
  }
  
  hideEnhancementOverlay() {
    if (this.enhancementOverlay) {
      this.enhancementOverlay.classList.remove('crkle-visible');
      setTimeout(() => {
        if (this.enhancementOverlay) {
          this.enhancementOverlay.remove();
          this.enhancementOverlay = null;
        }
      }, 200);
    }
  }
  
  applySuggestion(enhancement) {
    if (this.activeInput) {
      const currentText = this.activeInput.value;
      const newText = `${currentText} ${enhancement}`;
      this.activeInput.value = newText;
      
      // Trigger input event
      this.activeInput.dispatchEvent(new Event('input', { bubbles: true }));
      this.activeInput.focus();
      
      // Re-analyze after a short delay
      setTimeout(() => {
        this.analyzePrompt(newText, this.activeInput);
      }, 500);
      
      this.trackUsage('suggestion_applied');
    }
  }
  
  useEnhancedPrompt(enhancedPrompt) {
    if (this.activeInput) {
      this.activeInput.value = enhancedPrompt;
      this.activeInput.dispatchEvent(new Event('input', { bubbles: true }));
      this.activeInput.focus();
      this.hideEnhancementOverlay();
      
      this.trackUsage('enhanced_prompt_used');
      this.showSuccessNotification('Enhanced prompt applied! 🎉');
    }
  }
  
  copyEnhancedPrompt(enhancedPrompt) {
    navigator.clipboard.writeText(enhancedPrompt).then(() => {
      this.showSuccessNotification('Enhanced prompt copied to clipboard! 📋');
      this.trackUsage('prompt_copied');
    });
  }
  
  showWelcomeNotification() {
    const notification = document.createElement('div');
    notification.className = 'crkle-notification';
    notification.innerHTML = `
      <div class="notification-content">
        <span class="notification-icon">🧠</span>
        <span class="notification-text">CRKLE is ready to enhance your prompts on ${this.currentPlatform.name}!</span>
      </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => notification.classList.add('visible'), 100);
    setTimeout(() => {
      notification.classList.remove('visible');
      setTimeout(() => notification.remove(), 300);
    }, 3000);
  }
  
  showSuccessNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'crkle-notification success';
    notification.innerHTML = `
      <div class="notification-content">
        <span class="notification-text">${message}</span>
      </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => notification.classList.add('visible'), 100);
    setTimeout(() => {
      notification.classList.remove('visible');
      setTimeout(() => notification.remove(), 300);
    }, 2500);
  }
  
  getScoreClass(score) {
    if (score >= 8) return 'excellent';
    if (score >= 6) return 'good';
    if (score >= 4) return 'fair';
    return 'poor';
  }
  
  getScoreColor(score) {
    if (score >= 8) return '#10B981';
    if (score >= 6) return '#3B82F6';
    if (score >= 4) return '#F59E0B';
    return '#EF4444';
  }
  
  trackUsage(action) {
    // Send analytics to CRKLE backend
    fetch('https://api.crkle.com/analytics', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action,
        platform: this.currentPlatform.name,
        timestamp: Date.now(),
        url: window.location.href
      })
    }).catch(() => {}); // Ignore analytics errors
  }
}

// Initialize CRKLE Agent
if (!window.crkleAgent) {
  window.crkleAgent = new CRKLEAgent();
}