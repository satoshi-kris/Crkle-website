// CRKLE Popup Interface Logic
document.addEventListener('DOMContentLoaded', function() {
    initializePopup();
});

async function initializePopup() {
    // Check current tab and platform status
    await checkCurrentPlatform();
    
    // Load user statistics
    await loadUserStats();
    
    // Load settings
    await loadSettings();
    
    // Set up event listeners
    setupEventListeners();
    
    // Check if user should see upgrade banner
    checkUpgradeEligibility();
}

async function checkCurrentPlatform() {
    try {
        const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
        const url = tab.url;
        
        const statusDot = document.getElementById('statusDot');
        const statusText = document.getElementById('statusText');
        const currentPlatform = document.getElementById('currentPlatform');
        
        const platforms = {
            'bolt.new': { name: '⚡ Active on Bolt.new', icon: '⚡', active: true },
            'lovable.dev': { name: '💜 Active on Lovable', icon: '💜', active: true },
            'cursor.sh': { name: '⚡ Active on Cursor', icon: '⚡', active: true },
            'replit.com': { name: '🔥 Active on Replit', icon: '🔥', active: true }
        };
        
        let platformDetected = false;
        
        for (const [domain, info] of Object.entries(platforms)) {
            if (url.includes(domain)) {
                statusText.textContent = 'CRKLE is active!';
                currentPlatform.textContent = info.name;
                statusDot.classList.remove('inactive');
                platformDetected = true;
                break;
            }
        }
        
        if (!platformDetected) {
            statusText.textContent = 'Ready for vibe coding platforms';
            currentPlatform.textContent = '🎯 Navigate to Bolt.new, Lovable, Cursor, or Replit to start enhancing prompts';
            statusDot.classList.add('inactive');
        }
        
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

async function loadSettings() {
    try {
        const settings = await chrome.storage.sync.get([
            'realtime',
            'autoenhance',
            'scores',
            'notifications'
        ]);
        
        // Set toggle states based on stored settings
        const toggles = document.querySelectorAll('.toggle-switch');
        toggles.forEach(toggle => {
            const setting = toggle.dataset.setting;
            const isActive = settings[setting] !== false; // Default to true if not set
            
            if (isActive) {
                toggle.classList.add('active');
            } else {
                toggle.classList.remove('active');
            }
        });
        
    } catch (error) {
        console.error('Error loading settings:', error);
    }
}

function setupEventListeners() {
    // Toggle switches
    const toggles = document.querySelectorAll('.toggle-switch');
    toggles.forEach(toggle => {
        toggle.addEventListener('click', handleToggleClick);
    });
    
    // Track button clicks for analytics
    const buttons = document.querySelectorAll('.btn, .upgrade-btn');
    buttons.forEach(button => {
        button.addEventListener('click', (e) => {
            const action = e.target.textContent.trim();
            trackEvent('popup_button_clicked', { action });
        });
    });
}

async function handleToggleClick(event) {
    const toggle = event.target;
    const setting = toggle.dataset.setting;
    const isCurrentlyActive = toggle.classList.contains('active');
    
    // Toggle the visual state
    toggle.classList.toggle('active');
    
    // Save the setting
    const newValue = !isCurrentlyActive;
    await chrome.storage.sync.set({ [setting]: newValue });
    
    // Send message to content script about setting change
    try {
        const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
        await chrome.tabs.sendMessage(tab.id, {
            action: 'settingChanged',
            setting: setting,
            value: newValue
        });
    } catch (error) {
        // Content script might not be loaded, that's okay
    }
    
    // Track the setting change
    trackEvent('setting_changed', { setting, value: newValue });
    
    // Show feedback
    showSettingFeedback(setting, newValue);
}

function showSettingFeedback(setting, enabled) {
    const messages = {
        realtime: enabled ? 'Real-time suggestions enabled!' : 'Real-time suggestions disabled',
        autoenhance: enabled ? 'Auto-enhance mode enabled!' : 'Auto-enhance mode disabled',
        scores: enabled ? 'Quality scores enabled!' : 'Quality scores disabled',
        notifications: enabled ? 'Notifications enabled!' : 'Notifications disabled'
    };
    
    const message = messages[setting];
    if (message) {
        showToast(message);
    }
}

function showToast(message) {
    // Create toast notification
    const toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.textContent = message;
    toast.style.cssText = `
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: #FF6B35;
        color: #FAFAFA;
        padding: 8px 16px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 500;
        z-index: 1000;
        opacity: 0;
        transition: opacity 0.3s;
    `;
    
    document.body.appendChild(toast);
    
    // Animate in
    setTimeout(() => toast.style.opacity = '1', 10);
    
    // Remove after 2 seconds
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
    }, 2000);
}

async function checkUpgradeEligibility() {
    try {
        const stats = await chrome.storage.local.get(['promptsEnhanced', 'userTier']);
        const promptsEnhanced = stats.promptsEnhanced || 0;
        const userTier = stats.userTier || 'free';
        
        // Show upgrade banner if user is on free tier and has used CRKLE a few times
        if (userTier === 'free' && promptsEnhanced >= 5) {
            document.getElementById('upgradeBanner').style.display = 'block';
        }
        
    } catch (error) {
        console.error('Error checking upgrade eligibility:', error);
    }
}

function animateNumber(elementId, start, end, duration) {
    const element = document.getElementById(elementId);
    const startTime = performance.now();
    
    function animate(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Easing function for smooth animation
        const easeOut = 1 - Math.pow(1 - progress, 3);
        const current = start + (end - start) * easeOut;
        
        if (elementId === 'timesSaved') {
            element.textContent = (Math.round(current * 10) / 10).toFixed(1);
        } else {
            element.textContent = Math.round(current);
        }
        
        if (progress < 1) {
            requestAnimationFrame(animate);
        } else {
            element.textContent = elementId === 'timesSaved' ? end.toFixed(1) : end;
        }
    }
    
    requestAnimationFrame(animate);
}

async function trackEvent(action, data = {}) {
    try {
        // Send analytics to background script
        await chrome.runtime.sendMessage({
            action: 'trackEvent',
            event: action,
            data: {
                ...data,
                timestamp: Date.now(),
                source: 'popup'
            }
        });
    } catch (error) {
        // Ignore analytics errors
    }
}

// Update stats periodically while popup is open
setInterval(async () => {
    try {
        const stats = await chrome.storage.local.get(['promptsEnhanced', 'timesSaved']);
        const currentPrompts = parseInt(document.getElementById('promptsEnhanced').textContent) || 0;
        const currentTime = parseFloat(document.getElementById('timesSaved').textContent) || 0;
        
        const newPrompts = stats.promptsEnhanced || 0;
        const newTime = Math.round((stats.timesSaved || 0) * 10) / 10;
        
        // Update if numbers have changed
        if (newPrompts !== currentPrompts) {
            animateNumber('promptsEnhanced', currentPrompts, newPrompts, 800);
        }
        
        if (newTime !== currentTime) {
            animateNumber('timesSaved', currentTime, newTime, 800);
        }
        
    } catch (error) {
        // Ignore errors in periodic updates
    }
}, 2000); // Check every 2 seconds

// Handle messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'statsUpdated') {
        loadUserStats();
    } else if (message.action === 'platformChanged') {
        checkCurrentPlatform();
    }
    
    sendResponse({ received: true });
});

// Track popup open event
trackEvent('popup_opened');

async function loadUserStats() {
    try {
        const stats = await chrome.storage.local.get([
            'promptsEnhanced',
            'timesSaved',
            'lastUpdated'
        ]);
        
        const promptsEnhanced = stats.promptsEnhanced || 0;
        const timesSaved = Math.round((stats.timesSaved || 0) * 10) / 10; // Round to 1 decimal
        
        document.getElementById('promptsEnhanced').textContent = promptsEnhanced;
        document.getElementById('timesSaved').textContent = timesSaved;
        
        // Animate numbers if they're being updated
        if (promptsEnhanced > 0) {
            animateNumber('promptsEnhanced', 0, promptsEnhanced, 1000);
        }
        
        if (timesSaved > 0) {
            animateNumber('timesSaved', 0, timesSaved, 1200);
        }
        
    } catch (error) {
        console.error('Error loading user stats:', error);
    }
}