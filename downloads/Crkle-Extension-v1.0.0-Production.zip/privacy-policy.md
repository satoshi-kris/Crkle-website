# Privacy Policy for CRKLE Chrome Extension

**Last Updated: August 2025**

## Overview

CRKLE ("The Grammarly for AI Coding") is a Chrome extension that enhances AI prompts on coding platforms. This privacy policy explains how we collect, use, and protect your information.

## Information We Collect

### 1. Prompt Data
- **What**: Text content you type in supported coding platforms (Bolt.new, Lovable, Cursor, Replit)
- **Why**: To analyze and provide enhancement suggestions
- **How**: Only when you're actively using the extension on supported platforms
- **Retention**: Prompts are analyzed in real-time and not permanently stored

### 2. Usage Analytics
- **What**: Anonymous usage statistics (button clicks, enhancement usage, platform visits)
- **Why**: To improve the extension and understand user preferences
- **How**: Aggregated and anonymized data only
- **Retention**: 30 days maximum

### 3. Technical Data
- **What**: Browser type, extension version, error logs
- **Why**: To provide technical support and fix bugs
- **How**: Automatically collected for functionality
- **Retention**: 30 days maximum

## What We DON'T Collect

- ❌ Personal identification information
- ❌ Passwords or authentication tokens
- ❌ Complete code files or projects
- ❌ Browsing history outside supported platforms
- ❌ Email addresses or contact information

## How We Use Information

### Prompt Analysis
- Analyze your prompts to suggest improvements
- Provide quality scoring and enhancement recommendations
- Generate platform-specific suggestions

### Service Improvement
- Identify common prompt patterns
- Improve suggestion algorithms
- Fix bugs and add new features

### Analytics
- Understand which features are most useful
- Track extension performance and reliability
- Generate anonymous usage reports

## Data Sharing

**We DO NOT sell, rent, or share your personal data with third parties.**

### Limited Sharing
- **OpenAI API**: Prompts may be sent to OpenAI for analysis (subject to OpenAI's privacy policy)
- **Error Reporting**: Anonymous error logs may be sent to our monitoring service
- **Legal Requirements**: We may disclose information if required by law

## Data Security

### Protection Measures
- All data transmission is encrypted (HTTPS/TLS)
- No permanent storage of prompt content
- Secure cloud infrastructure (Vercel)
- Regular security audits and updates

### Your Rights
- **Access**: Request information about data we have
- **Deletion**: Request deletion of your data
- **Opt-out**: Disable analytics in extension settings
- **Uninstall**: Remove extension to stop all data collection

## Third-Party Services

### OpenAI
- We may send prompts to OpenAI for analysis
- Subject to OpenAI's privacy policy and terms
- You can disable this in extension settings

### Vercel (Hosting)
- Our API is hosted on Vercel infrastructure
- Subject to Vercel's security and privacy standards
- Data processed in secure cloud environment

## Children's Privacy

CRKLE is not intended for children under 13. We do not knowingly collect information from children under 13.

## Changes to Privacy Policy

We may update this privacy policy occasionally. Changes will be posted:
- In the extension
- On our website (https://crkle.com)
- In the Chrome Web Store listing

## Contact Us

If you have questions about this privacy policy:

- **Email**: privacy@crkle.com
- **Website**: https://crkle.com/privacy
- **Chrome Store**: Report via extension listing

## Your Choices

### Extension Settings
- Enable/disable real-time suggestions
- Turn off analytics tracking
- Disable OpenAI API integration
- Control notification preferences

### Browser Controls
- Manage extension permissions in Chrome settings
- Uninstall extension to stop all data collection
- Clear browser data to remove cached information

## Data Retention

- **Prompt Analysis**: Not stored permanently
- **Analytics**: 30 days maximum
- **Error Logs**: 30 days maximum
- **Settings**: Until extension is uninstalled

---

**By using CRKLE, you consent to this privacy policy.**

This policy is designed to be transparent about our data practices while protecting your privacy. We believe in minimal data collection and maximum user control.